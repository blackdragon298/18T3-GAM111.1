﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HighscoreDisplay : MonoBehaviour
{
	public Text[] scoreTexts;

	// Use this for initialization
	void Start()
	{
		foreach (Text i in scoreTexts)
		{
			
		}
	}

	// Update is called once per frame
	void Update()
	{

	}
}
